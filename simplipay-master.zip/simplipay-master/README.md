# simplipay2
This is an online transaction platform made for SY UG college project.
In this, Django is used as backend and
mysql database
It has all basic transaction platform features like,
It has email, phone verification and authentication system for signup
transation pin is required before a transaction
Auto email updates for every transaction
Transaction History
Profile and personalised qr on homepage
Multiple payment option(Bank A/c, userid)
QR transaction
Request Money
Balance Update
Contact and support
